# Greek Text
CEN4010 Software Engineering I Project: An online web application bookstore
# Get Started
Updating.....
# Functionality
## Book Browsing and Sorting by Ethan Hernandez
Users will have a simple and enjoyable way to discover new books and authors and sort results.
## Profile Management by all group members
Users can create and maintain their profiles rather than enter in their information each time they order.
## Shopping Cart by Kevin Garcia
Users can manage items in a shopping cart for immediate or future purchase.
## Book Details by Ha Ho
Users can see informatice and enticing details about a book.
## Book Rating and Commenting by Julian Gonzalez 
Users can rate and comment on books they've purchased to help others in their selection.
## Wish List Management by Andres Hernandez
Users can create and have 3 different wish lists which have books moved to from the primary list.

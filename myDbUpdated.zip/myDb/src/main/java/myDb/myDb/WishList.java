package myDb.myDb;

public class WishList extends ShoppingCart{
    ShoppingCart myWishList = new ShoppingCart();

    @Override
    public void addToCart(String itemName, double price, int quantity) {
        super.addToCart(itemName, price, quantity);
    }

    public void setMyWishList(ShoppingCart myWishList) {
        this.myWishList = myWishList;
    }
}

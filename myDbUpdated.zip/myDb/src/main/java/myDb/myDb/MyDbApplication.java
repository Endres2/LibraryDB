package myDb.myDb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyDbApplication.class, args);


	}

}

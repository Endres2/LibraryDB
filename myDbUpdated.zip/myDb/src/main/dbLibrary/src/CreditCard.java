package com.bookstore.BookStoreDemo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.math.BigInteger;

@Entity
@Table(name = "Shopping Cart")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ShoppingCart {

    @Id
    @Column(name = "Name")
    private String name;
    @Column(name = "Book", unique = true, nullable = false)
    private String book;
    @Column(name = "Price")
    private Long price;
    @Column(name = "Quantity")
    private Integer quantity;



    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "userID", nullable = false)
    @JsonIgnore
    private User user;

    //For Deserialization
    public ShoppingCart() {}

    public ShoppingCart(String name, String book, Long price, Integer quantity) {
        this.name = name;
        this.book = book;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public void setName(String cardName) {
        this.name = cardName;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public Long getPrice() {
        return price;
    }

    public void setQuantity(Integer expirationDate) {
        this.quantity = quantity;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }



}

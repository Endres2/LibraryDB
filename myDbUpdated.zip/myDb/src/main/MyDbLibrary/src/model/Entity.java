package model;

public @interface Entity {
}

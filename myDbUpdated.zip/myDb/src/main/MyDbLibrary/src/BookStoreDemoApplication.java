import org.springframework.boot.SpringApplication;

@SpringBootApplication
public class BookStoreDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreDemoApplication.class, args);
	}

}

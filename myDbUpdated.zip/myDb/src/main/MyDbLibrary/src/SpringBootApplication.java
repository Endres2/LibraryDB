public @interface SpringBootApplication {
}
